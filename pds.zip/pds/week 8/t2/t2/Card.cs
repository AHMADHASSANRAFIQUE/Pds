﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t2
{
    internal class Card
    {
        private int value;
        private int suit;

        public Card(int theValue, int theSuit)
        {
            value = theValue;
            suit = theSuit;
        }

        public string GetSuitAsString()
        {
            switch (suit)
            {
                case 1: return "Clubs";
                case 2: return "Diamonds";
                case 3: return "Spades";
                case 4: return "Hearts";
                default: return "Unknown";
            }
        }

        public string GetValueAsString()
        {
            if (value >= 2 && value <= 10)
            {
                return value.ToString();
            }
            switch (value)
            {
                case 1: return "Ace";
                case 11: return "Jack";
                case 12: return "Queen";
                case 13: return "King";
                default: return "Unknown";
            }
        }

        public override string ToString()
        {
            return $"{GetValueAsString()} of {GetSuitAsString()}";
        }
    }
}
