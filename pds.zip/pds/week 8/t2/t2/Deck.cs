﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t2
{
    internal class Deck
    {
        private List<Card> cards;
        private int currentCard;
        private Random random;

        public Deck()
        {
            cards = new List<Card>(52);
            currentCard = 0;
            random = new Random();

            for (int i = 0; i < 52; i++)
            {
                cards.Add(new Card((i % 13) + 1, (i / 13) + 1));
            }
        }

        public void Shuffle()
        {
            currentCard = 0;

            for (int i = 0; i < cards.Count; i++)
            {
                int randomIndex = random.Next(52);
                Card temp = cards[i];
                cards[i] = cards[randomIndex];
                cards[randomIndex] = temp;
            }
        }

        public int CardsLeft()
        {
            return 52 - currentCard;
        }

        public Card DealCard()
        {
            if (currentCard < 52)
            {
                return cards[currentCard++];
            }
            else
            {
                return null;
            }
        }
    }
}
