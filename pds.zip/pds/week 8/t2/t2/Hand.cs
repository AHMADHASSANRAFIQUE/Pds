﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t2
{
    internal class Hand
    {
        private List<Card> cards;

        public Hand()
        {
            cards = new List<Card>();
        }

        public void Clear()
        {
            cards.Clear();
        }

        public void AddCard(Card c)
        {
            cards.Add(c);
        }

        public void RemoveCard(Card c)
        {
            cards.Remove(c);
        }

        public void RemoveCard(int position)
        {
            if (position >= 0 && position < cards.Count)
            {
                cards.RemoveAt(position);
            }
        }

        public int GetCardCount()
        {
            return cards.Count;
        }

        public Card GetCard(int position)
        {
            if (position >= 0 && position < cards.Count)
            {
                return cards[position];
            }
            else
            {
                return null;
            }
        }

        public void SortBySuit()
        {
            cards.Sort((c1, c2) => {
                int suitComparison = c1.GetSuitAsString().CompareTo(c2.GetSuitAsString());
                if (suitComparison == 0)
                {
                    return c1.GetValueAsString().CompareTo(c2.GetValueAsString());
                }
                else
                {
                    return suitComparison;
                }
            });
        }

        public void SortByValue()
        {
            cards.Sort((c1, c2) => {
                int valueComparison = c1.GetValueAsString().CompareTo(c2.GetValueAsString());
                if (valueComparison == 0)
                {
                    return c1.GetSuitAsString().CompareTo(c2.GetSuitAsString());
                }
                else
                {
                    return valueComparison;
                }
            });
        }

        public override string ToString()
        {
            string handString = "";
            foreach (Card card in cards)
            {
                handString += card.ToString() + "\n";
            }
            return handString;
        }
    }
}
