﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to HighLow game!");

            int totalScore = 0;
            int numGames = 0;

            while (true)
            {
                Deck deck = new Deck();
                deck.Shuffle();
                int score = PlayGame(deck);
                totalScore += score;
                numGames++;

                Console.WriteLine($"Your score for this game: {score}");
                Console.WriteLine("Do you want to play again? (yes/no)");
                string choice = Console.ReadLine().ToLower();
                if (choice != "yes")
                {
                    break;
                }
            }

            double averageScore = (double)totalScore / numGames;
            Console.WriteLine($"Your average score: {averageScore:F2}");
        }

        public static int PlayGame(Deck deck)
        {
            int score = 0;

            Hand hand = new Hand();
            hand.AddCard(deck.DealCard());
            Console.WriteLine($"First card: {hand.GetCard(0)}");

            while (true)
            {
                Console.Write("Will the next card be higher or lower? (h/l): ");
                string guess = Console.ReadLine().ToLower();

                Card currentCard = hand.GetCard(hand.GetCardCount() - 1);
                Card nextCard = deck.DealCard();
                if (nextCard == null)
                {
                    break;
                }
                hand.AddCard(nextCard);
                Console.WriteLine($"Next card: {nextCard}");

                int currentValue = int.Parse(currentCard.GetValueAsString());
                int nextValue = int.Parse(nextCard.GetValueAsString());


                if ((guess == "h" && nextValue - currentValue > 0) ||
                    (guess == "l" && nextValue - currentValue < 0))
                {
                    Console.WriteLine("Correct!");
                    score++;
                }
                else
                {
                    Console.WriteLine("Incorrect!");
                    break;
                }

            }

            return score;
        }
    }
    }
