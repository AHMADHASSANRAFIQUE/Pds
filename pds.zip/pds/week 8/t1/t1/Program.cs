﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Staff s = new Staff("ahmad", "harabnspura", "govt", 12000);
            Console.WriteLine(s.toString());
            Console.ReadKey();
        }
    }
}
