﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using t1;
namespace t1
{
    internal class Person
    {
        protected string Name;
        protected string Address;
        public Person(string name, string address)
        {
            this.Name = name;
            this.Address = address;
        }
        public Person()
        {

        }
        public string getName()
        {
            return Name;
        }      
        public string getAddress()
        {
            return Address;
        }     
        public void setAddress(string add)
        {
            Address = add;
        }
        public void setName(string n)
        {
            Name = n;
        }
        public string toString()
        {
            string st = $"Person[Name = {Name}, Address = {Address}]";
            return st;
        }
    }
}
