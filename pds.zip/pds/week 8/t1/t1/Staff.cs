﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using t1;
namespace t1
{
    internal class Staff : Person
    {
        private string School;
        private double Pay;
        public Staff(string name,string address,string school, double pay) :base(name,address)
        {
            this.School = school;
            this.Pay = pay;
        }
        public string getSchool()
        {
            return School;
        }
        public double getPay()
        {
            return Pay;
        }
        public void setSchool(string sch)
        {
            School = sch;
        }
        public void setPay(double p)
        {
            Pay = p;
        }
        public new string toString()
        {

           // string st = $"[Person[name = {Name}, addrress = {Address}],school = {School} , pay = {Pay}";
            string st = $"[{base.toString()}],school = {School} , pay = {Pay}";
            return st;
        }
    }
}
