﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using t1;
namespace t1
{
    internal class Student : Person
    {
        private string Program;
        private int Year;
        private double Fee;
        public Student(string name, string address, string program, int year, double fee)
        {
            this.Program = program;
            this.Year = year;
            this.Fee = fee;
        }
        public string getProgram()
        {
            return Program;
        }
        public int getYear()
        {
            return Year;
        }
        public double getFee()
        {
            return Fee;
        }
        public void setProgram(string p)
        {
            Program = p;
        }
        public void setYear(int y)
        {
           Year = y;
        }
        public void setFee(double f)
        {
            Fee = f; 
        }
        public new string toString()
        {
            string st = $"[{base.toString()}],program = {Program} , year = {Year},fee = {Fee}";
            return st;
        }
    }
}
