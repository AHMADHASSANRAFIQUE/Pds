﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t3
{
    internal class Hand
    {
        protected Card[] cards;
        protected int numberOfCards;

        public Hand()
        {
            cards = new Card[10];
            numberOfCards = 0;
        }

        public void AddCard(Card card)
        {
            if (numberOfCards < 10)
            {
                cards[numberOfCards++] = card;
            }
            else
            {
                throw new IndexOutOfRangeException("Hand is full");
            }
        }

        public void Clear()
        {
            for (int i = 0; i < numberOfCards; i++)
            {
                cards[i] = null;
            }
            numberOfCards = 0;
        }

        public int GetTotalValue()
        {
            int totalValue = 0;
            int aceCount = 0;

            foreach (var card in cards)
            {
                if (card != null)
                {
                    totalValue += card.GetValue();
                    if (card.GetValue() == 1)
                    {
                        aceCount++;
                    }
                }
            }

            while (totalValue <= 11 && aceCount > 0)
            {
                totalValue += 10;
                aceCount--;
            }

            return totalValue;
        }

        public override string ToString()
        {
            string handString = "";
            foreach (Card card in cards)
            {
                if (card != null)
                {
                    handString += card.ToString() + "\n";
                }
            }
            return handString;
        }
    }
}
