﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t3
{
    internal class BlackjackHand : Hand
    {
        public int GetBlackjackValue()
        {
            return GetTotalValue();
        }
    }
}
