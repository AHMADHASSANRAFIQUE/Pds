﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace t3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Blackjack!");

            Deck deck = new Deck();
            deck.Shuffle();

            BlackjackHand playerHand = new BlackjackHand();
            BlackjackHand dealerHand = new BlackjackHand();

            playerHand.AddCard(deck.DealCard());
            playerHand.AddCard(deck.DealCard());
            dealerHand.AddCard(deck.DealCard());
            dealerHand.AddCard(deck.DealCard());

            Console.WriteLine("Your cards:");
            Console.WriteLine(playerHand);

            Console.WriteLine("Dealer's cards:");


            while (true)
            {
                Console.WriteLine("Hit or Stand? (h/s)");
                string choice = Console.ReadLine().ToLower();
                if (choice == "h")
                {
                    playerHand.AddCard(deck.DealCard());
                    Console.WriteLine("Your cards:");
                    Console.WriteLine(playerHand);
                    if (playerHand.GetBlackjackValue() > 21)
                    {
                        Console.WriteLine("Bust! You lose.");
                        return;
                    }
                }
                else if (choice == "s")
                {
                    break;
                }
            }

            Console.WriteLine("Dealer's cards:");
            Console.WriteLine(dealerHand);
            while (dealerHand.GetBlackjackValue() < 17)
            {
                dealerHand.AddCard(deck.DealCard());
                Console.WriteLine("Dealer hits...");
                Console.WriteLine("Dealer's cards:");
                Console.WriteLine(dealerHand);
            }

            int playerScore = playerHand.GetBlackjackValue();
            int dealerScore = dealerHand.GetBlackjackValue();

            Console.WriteLine($"Your score: {playerScore}");
            Console.WriteLine($"Dealer's score: {dealerScore}");

            if (playerScore > 21)
            {
                Console.WriteLine("Bust! You lose.");
            }
            else if (dealerScore > 21 || playerScore > dealerScore)
            {
                Console.WriteLine("You win!");
            }
            else if (playerScore == dealerScore)
            {
                Console.WriteLine("It's a tie.");
            }
            else
            {
                Console.WriteLine("Dealer wins.");
            }
        }
    }
    }
